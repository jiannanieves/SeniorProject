/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */

typedef struct {
    int m[15][11];
} letter2d;

extern int A[15][11];
extern int A[15][11];
extern int B[15][11];
extern int C[15][11];
extern int D[15][11];
extern int E[15][11];
extern int F[15][11];
extern int G[15][11];
extern int H[15][11];
extern int I[15][11];
extern int J[15][11];
extern int K[15][11];
extern int L[15][11];
extern int M[15][11];
extern int N[15][11];
extern int O[15][11];
extern int P[15][11];
extern int Q[15][11];
extern int R[15][11];
extern int S[15][11];
extern int T[15][11];
extern int U[15][11];
extern int V[15][11];
extern int W[15][11];
extern int X[15][11];
extern int Y[15][11];
extern int Z[15][11];